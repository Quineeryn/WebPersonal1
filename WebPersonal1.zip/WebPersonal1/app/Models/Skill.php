<?php


namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Skill extends Model
{
    use HasFactory;

    protected $fillable = ['nama_skill', 'rentan_skill'];

    // Relasi dengan model Personal
    public function personal()
    {
        return $this->belongsTo(Personal::class);
    }
}
