<?php

// app/Http/Controllers/SkillController.php

namespace App\Http\Controllers;

use App\Models\Skill;
use Illuminate\Http\Request;

class SkillController extends Controller
{
    public function show()
    {
        $skills = Skill::all();
        return view('skills.show', compact('skills'));
    }
    
    public function create($personalId)
    {
        return view('skills.create', compact('personalId'));
    }

    public function store(Request $request)
    {
        // Validasi data formulir
        $request->validate([
            'name' => 'required|string|max:255',
            'range' => 'required|integer|min:1|max:100',
        ]);

        // Simpan data ke database
        Skill::create([
            'name' => $request->input('name'),
            'range' => $request->input('range'),
        ]);

        // Redirect kembali ke halaman skill show
        return redirect('/skillshow');
    }

    public function edit($skillId)
    {
        $skill = Skill::findOrFail($skillId);
        return view('skills.edit', compact('skill'));
    }

    public function update(Request $request, $personalId, $skillId)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'range' => 'required|numeric|min:1|max:100',
        ]);
    
        $skill = Skill::findOrFail($skillId);
        $skill->update([
            'name' => $request->name,
            'range' => $request->range,
        ]);
    
        return redirect()->route('personal.edit', $personalId)->with('success', 'Skill updated successfully!');
    }
    

    public function destroy($personalId, $skillId)
    {
        $skill = Skill::findOrFail($skillId);
        $skill->delete();

        return redirect()->route('personal.edit', $personalId)->with('success', 'Skill deleted successfully!');
    }



}

