<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Skill;

class SkillsTableSeeder extends Seeder
{
    public function run()
    {
        Skill::create(['name' => 'Programming', 'range' => 80]);
        Skill::create(['name' => 'Design', 'range' => 70]);
       // Tambah
    }
