<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSkillsTable extends Migration
{
    public function up()
    {
        Schema::create('skills', function (Blueprint $table) {
            $table->id();
           // $table->foreignId('personal_id')->constrained(); // Menambahkan foreign key ke tabel personals
            $table->string('name')->nullable();;
            $table->integer('range')->nullable();;
            $table->timestamps()->nullable();;
        });
    }

    public function down()
    {
        Schema::dropIfExists('skills');
    }
}
