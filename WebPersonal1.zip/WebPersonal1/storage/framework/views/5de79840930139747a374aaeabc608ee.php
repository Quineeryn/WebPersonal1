<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">

                <?php if(session('message')): ?>
                    <div class="alert alert-success"><?php echo e('Data successfully added!'); ?></div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header">
                        <h4>
                            Personal Information
                            <a href="<?php echo e(url('/personal/create')); ?>" class="btn btn-primary float-end">Add Personal
                                Information</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Foto</th>
                                    <th>Desc</th>
                                    <th>Name</th>
                                    <th>email</th>
                                    <th>address</th>
                                    <th>PN</th>
                                    <th>city</th>
                                    <th>link</th>
                                    <th>Inst</th>
                                    <th>Loc</th>
                                    <th>Start</th>
                                    <th>End</th>
                                    <th>Achiev</th>
                                    <th>EduLevel</th>
                                    <th>comp</th>
                                    <th>Jl</th>
                                    <th>Stdt</th>
                                    <th>Eddt</th>
                                    <th>Jdesc</th>
                                    <th>Jtit</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $personal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemP): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>

                                        <td><?php echo e($itemP->id); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset('fotopersonal/' . $itemP->foto)); ?>" alt=""
                                                style="width: 40px;">
                                        </td>
                                        <td><?php echo e($itemP->deskripsi); ?></td>
                                        <td><?php echo e($itemP->full_name); ?></td>
                                        <td><?php echo e($itemP->email); ?></td>
                                        <td><?php echo e($itemP->address); ?></td>
                                        <td>0<?php echo e($itemP->telephone_number); ?></td>
                                        <td><?php echo e($itemP->city); ?></td>
                                        <td><?php echo e($itemP->link_profile); ?></td>

                                        <?php $__currentLoopData = $itemP->education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($education->Edu_institution); ?></td>
                                            <td><?php echo e($education->Loc_edu); ?></td>
                                            <td><?php echo e($education->Start_date_edu); ?></td>
                                            <td><?php echo e($education->End_date_edu); ?></td>
                                            <td><?php echo e($education->Achievment); ?></td>
                                            <td><?php echo e($education->Education_level); ?></td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php $__currentLoopData = $itemP->experience; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($experience->Company_name); ?></td>
                                            <td><?php echo e($experience->Loc_org); ?></td>
                                            <td><?php echo e($experience->Start_date_org); ?></td>
                                            <td><?php echo e($experience->End_date_org); ?></td>
                                            <td><?php echo e($experience->Job_desc); ?></td>
                                            <td><?php echo e($experience->Job_title); ?></td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        <td>
                                            <a href="<?php echo e(url('personaledit/' . $itemP->id . '/edit')); ?>"
                                                class="btn btn-success btn-sm">Edit</a>

                                            <form action="<?php echo e(url('personaldelete/' . $itemP->id . '/delete')); ?>"
                                                method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>

                                                <button type="submit" class="btn btn-danger delete"
                                                    data-id="<?php echo e($itemP->id); ?>">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
                                <script src="https://code.jquery.com/jquery-3.7.1.slim.js"
                                    integrity="sha256-UgvvN8vBkgO0luPSUl2s8TIlOSYRoGFAX4jlCIm9Adc=" crossorigin="anonymous"></script>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
        <script>
            $(document).ready(function() {
                $('.delete').click(function(e) {
                    e.preventDefault(); // Prevent the default form submission

                    var form = $(this).closest('form');

                    //var personalid = $(this).attr('data-id');

                    swal({
                        title: "Are you sure?",
                        text: "Once deleted, you will not be able to recover data ",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    }).then((willDelete) => {
                        if (willDelete) {
                            form.submit(); // Submit the form when user confirms deletion
                            swal("Poof! Your imaginary file has been deleted!", {
                                icon: "success",
                            });
                        } else {
                            swal("Data is not deleted.");
                        }
                    });
                });
            });
        </script>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Webcravitae\WebPersonal1\resources\views/personal/index.blade.php ENDPATH**/ ?>