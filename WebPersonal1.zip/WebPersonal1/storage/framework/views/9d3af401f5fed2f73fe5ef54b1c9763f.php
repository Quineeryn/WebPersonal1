<?php echo $__env->make('layouts.headercv', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<!DOCTYPE html>
<html lang="en">


<body>
  <!-- Home - Page Registered -->
  <div class="page-registered">
    <div class="frame-posisi">
      <div class="frame-client-likes">

        <div class="frame-discover-create">
          <div class="frame-cv-welcome">
            <div class="cv-maker-platform">
              HELLO FRIENDS!
            </div>
            <div class="frame-welcome-discover">
              <div class="hi-welcome-to-cravitae">
                I'm    <?php echo e(Auth::user()->name); ?> 
              </div>

            </div>
          </div>
          <div class="posisi-explore">
            <div class="style-create-your-own">
              <a href="<?php echo e(url('/formpersonal')); ?>" class="create-your-own">
                Let's Begin
              </a>
            </div>
              
          </div>
        </div>




      </div>
    </div>

    <!-- <img class="image-thumbnail-registered" src="../image/image-home.png" alt="Home Image"> -->

  </div>

</body>


</html>



    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet" />
    <script>
        AOS.init();
    </script>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\Webcravitae\WebPersonal1\resources\views/cobacvats.blade.php ENDPATH**/ ?>