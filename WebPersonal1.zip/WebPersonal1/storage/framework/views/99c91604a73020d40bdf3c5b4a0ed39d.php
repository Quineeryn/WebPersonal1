<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- About - Page Registered -->

  <div class="creator1">
    <div class="container-box">
      <img class="image-female" src="../image/cewe.png" alt="Profile Image">
      <div class="frame-aboutme">
        <div class="name-aboutme">
          <div class="name-creator">
            Athalie Aurora
          </div>
          <div class="github-box">
            <a href="https://github.com/athalie-aurora" class="github-text">github</a>
          </div>
        </div>
        <div class="deskripsi-me">
          I am an enthusiastic technology enthusiast.
          I enjoy exploring the latest innovations and learning how technology can reshape the world. 
        </div>
      </div>
    </div>
  </div>

  <div class="creator2">
    <div class="container-box">
      <img class="image-gentleman " src="../image/cowo.png" alt="Profile Image">
      <div class="frame-aboutme">
        <div class="name-aboutme">
          <div class="name-creator">
            Canandra Eka
          </div>
          <div class="github-box">
            <a href="https://github.com/Quineeryn" class="github-text">github</a>
          </div>
        </div>
        <div class="deskripsi-me">
          I'm a college student 
        </div>
      </div>
    </div>
  </div>

  <div class="creator3">
    <div class="container-box">
      <img class="image-female " src="../image/cewe.png" alt="Profile Image">
      <div class="frame-aboutme">
        <div class="name-aboutme">
          <div class="name-creator">
            Fathia Qurrata
          </div>
          <div class="github-box">
            <a href="https://github.com/fathiaqurrata" class="github-text">github</a>
          </div>
        </div>
        <div class="deskripsi-me">
          I'm a college student 
        </div>
      </div>
    </div>
  </div>

  
  <div class="creator4">
    <div class="container-box">
      <img class="image-female " src="../image/cewe.png" alt="Profile Image">
      <div class="frame-aboutme">
        <div class="name-aboutme">
          <div class="name-creator">
            Xaviera Sadiya
          </div>
          <div class="github-box">
            <a href="https://github.com/XavieraSal" class="github-text">github</a>
          </div>
        </div>
        <div class="deskripsi-me">
          I'm a college student 
        </div>
      </div>
    </div>
  </div>


  <div class="content">
    <!-- Untuk Tambahan lain -->
    
  </div>

  <!-- <footer>
    <p>&copy; 2023 Cravitae</p>
  </footer> -->
</body>

</html>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH D:\Webcravitae\WebPersonal1\resources\views/about.blade.php ENDPATH**/ ?>