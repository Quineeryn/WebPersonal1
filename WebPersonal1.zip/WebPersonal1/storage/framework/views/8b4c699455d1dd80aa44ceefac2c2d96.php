<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="stylesheet" href="../css/cravitae.css">


  <title>Home - Cravitae</title>
</head>


    <!-- Header -->
    <header>
    <div class="logo">
      <span class="cravitae">Cravitae</span>
    </div>

    <nav class="menu">
      <span></span>
      <a href="<?php echo e(url('/')); ?>" class="navbar">Home</a>
      <a href="<?php echo e(url('about')); ?>" class="navbar">About</a>
    </nav>

    <?php if(Auth::guest()): ?>
    <!-- Login
    Register -->
    <li><a href="<?php echo e(url('/login')); ?>">Login</a></li>
    <li><a href="<?php echo e(url('/register')); ?>">Register</a></li>
    
    <?php else: ?>
    <div class="acc-signout">
      <div class="frame-acc-signout">

        <div class="circle-acc">
          <!-- <div class="one-font">
            C
          </div> -->

          <a href="#" class="one-font">C</a>
          
        </div>

        <div class="name-font">
        <?php echo e(Auth::user()->name); ?> 
        </div>
      </div>

      <a href="<?php echo e(url('/logout')); ?>" class="sign-out"> Sign Out →</a>
      
    </div>
    <?php endif; ?>

  </header>



  <!-- End Header --><?php /**PATH D:\Webcravitae\WebPersonal1\resources\views/layouts/header.blade.php ENDPATH**/ ?>