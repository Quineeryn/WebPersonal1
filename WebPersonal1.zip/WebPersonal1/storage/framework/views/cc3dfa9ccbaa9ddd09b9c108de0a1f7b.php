<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<!DOCTYPE html>
<html lang="en">


<body>
  <!-- Home - Page Registered -->
  <div class="page-registered">
    <div class="frame-posisi">
      <div class="frame-client-likes">

        <div class="frame-discover-create">
          <div class="frame-cv-welcome">
            <div class="cv-maker-platform">
              CV MAKER PLATFORM
            </div>
            <div class="frame-welcome-discover">
              <div class="hi-welcome-to-cravitae">
                Hi, Welcome to Cravitae!
              </div>
              <div class="discover-new-job-opportunities-with-connect-and-expand-your-network">
                Discover New Job Opportunities with Connect and Expand Your Network.
              </div>
            </div>
          </div>
          <div class="posisi-explore">
            <div class="style-create-your-own">
              <a href="<?php echo e(url('/coba')); ?>" class="create-your-own">
                Create your own →
              </a>
            </div>


              <a href="<?php echo e(url('/cvats')); ?>" class="style-explore">
              <div class="explore">
                Explore →
              </div>
              </a>

              
          </div>
        </div>

        <div class="posisi-likes">

          <div class="jarak-item-font">
            <div class="petir-angka">
              <svg class="vectorpetir" width="20" height="25" viewBox="0 0 20 25" fill="none"
                xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M19.9095 0.281225C19.8793 0.213732 19.8302 0.156473 19.768 0.116424C19.7059 0.0763755 19.6334 0.0552667 19.5595 0.0556697H8.72505C8.65998 0.0557781 8.59598 0.0722117 8.53891 0.103465C8.48184 0.134719 8.43352 0.179793 8.39839 0.234559L0.0683863 13.4568C0.0282832 13.5144 0.00485251 13.5819 0.000675921 13.6519C-0.00350067 13.722 0.0117389 13.7918 0.0447157 13.8537C0.0776924 13.9157 0.127126 13.9673 0.18757 14.0029C0.248013 14.0386 0.31712 14.0568 0.387275 14.0557H6.35283L1.08728 24.3612C1.05704 24.4225 1.04283 24.4905 1.04597 24.5587C1.04911 24.627 1.0695 24.6933 1.10523 24.7516C1.14096 24.8099 1.19086 24.8581 1.25029 24.8918C1.30971 24.9256 1.37672 24.9437 1.44505 24.9446H3.77839C3.83236 24.9449 3.88583 24.934 3.93537 24.9126C3.98492 24.8912 4.02946 24.8597 4.06616 24.8201L17.7317 10.0501C17.786 9.99482 17.8225 9.92458 17.8365 9.8484C17.8506 9.77222 17.8416 9.69357 17.8107 9.62255C17.7798 9.55152 17.7284 9.49134 17.663 9.44973C17.5977 9.40812 17.5214 9.38697 17.4439 9.389H12.2017L19.8473 0.693447C19.8966 0.638206 19.9287 0.569804 19.9397 0.496598C19.9508 0.423393 19.9403 0.348554 19.9095 0.281225Z"
                  fill="#2B788B" />
              </svg>
              <div class>
                <span>
                  <span class="_client-span1">4</span>
                  <span class="_client-span2"></span>
                  <span class="_client-span3">+</span>
                </span>
              </div>
            </div>
            <div class="client">Client</div>
          </div>


          <svg class="vectorpetir" height="40" viewBox="0 0 0 40" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 0V40" stroke="#E0E0E0" />
          </svg>
          <div class="frame-32">
            <div class="petir-angka">
              <svg class="vector2" width="21" height="25" viewBox="0 0 21 25" fill="none"
                xmlns="http://www.w3.org/2000/svg">
                <path
                  d="M20.8536 0.281225C20.8234 0.213732 20.7743 0.156473 20.7121 0.116424C20.65 0.0763755 20.5775 0.0552667 20.5036 0.0556697H9.66914C9.60408 0.0557781 9.54008 0.0722117 9.483 0.103465C9.42593 0.134719 9.37761 0.179793 9.34248 0.234559L1.01248 13.4568C0.972375 13.5144 0.948944 13.5819 0.944768 13.6519C0.940591 13.722 0.955831 13.7918 0.988807 13.8537C1.02178 13.9157 1.07122 13.9673 1.13166 14.0029C1.1921 14.0386 1.26121 14.0568 1.33137 14.0557H7.29692L2.03137 24.3612C2.00114 24.4225 1.98693 24.4905 1.99007 24.5587C1.99321 24.627 2.01359 24.6933 2.04932 24.7516C2.08505 24.8099 2.13496 24.8581 2.19438 24.8918C2.25381 24.9256 2.32081 24.9437 2.38914 24.9446H4.72248C4.77646 24.9449 4.82992 24.934 4.87946 24.9126C4.92901 24.8912 4.97355 24.8597 5.01026 24.8201L18.6758 10.0501C18.7301 9.99482 18.7666 9.92458 18.7806 9.8484C18.7947 9.77222 18.7857 9.69357 18.7548 9.62255C18.7239 9.55152 18.6724 9.49134 18.6071 9.44973C18.5418 9.40812 18.4655 9.38697 18.388 9.389H13.1458L20.7914 0.693447C20.8407 0.638206 20.8728 0.569804 20.8838 0.496598C20.8949 0.423393 20.8844 0.348554 20.8536 0.281225Z"
                  fill="#2B788B" />
              </svg>
              <div>
                <span>
                  <span class="_likes-span1">100</span>
                  <span class="_likes-span2"></span>
                  <span class="_likes-span3">+</span>
                </span>
              </div>
            </div>
            <div class="likes">
              Likes
            </div>
          </div>
        </div>


      </div>
    </div>

    <img class="image-thumbnail-registered" src="../image/image-home.png" alt="Home Image">

  </div>

</body>


</html>



    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet" />
    <script>
        AOS.init();
    </script>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\Webcravitae\WebPersonal1\resources\views/home.blade.php ENDPATH**/ ?>