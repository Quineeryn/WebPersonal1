<!-- Bagian Bawah Halaman -->
<footer>
    <p>© 2023 Cravitae. Project for Proyek 3.</p>
</footer>
<?php /**PATH D:\Webcravitae\WebPersonal1\resources\views/layouts/footer.blade.php ENDPATH**/ ?>