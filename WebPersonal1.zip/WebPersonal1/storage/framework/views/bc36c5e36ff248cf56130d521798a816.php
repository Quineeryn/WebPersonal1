
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!DOCTYPE html>
<html lang="en">

<body>

  <div class="form-container">
    <!-- Form -->
    <form action="<?php echo e(url('/updateskill/'.$skill->id)); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('put'); ?>

      <div class="input2">
        <div class="label">
          <div class="label2">Description (Optional)</div>
        </div>
        <div class="frame">
          <div class="frame2">
            <input type="text" name="desc" placeholder="Enter text">
          </div>
        </div>
      </div>

      <div class="judul">
        <h1>Skill Information</h1>
      </div>

      <div class="input">
        <div class="label">
          <label for="skill-name" class="label2">Skill Name</label>
        </div>
        <div class="frame">
          <div class="frame2">
            <input type="text" id="skill-name" name="name" value="<?php echo e($skill->name); ?>" placeholder="Enter text" required>
          </div>
        </div>
      </div>

      <div class="input3">
        <div class="label">
          <div class="label2">Skill Range (1-100)</div>
        </div>
        <div class="frame">
          <div class="frame2">
            <input type="number" name="range" value="<?php echo e($skill->range); ?>" placeholder="Enter number" required min="1" max="100">
          </div>
        </div>
      </div>

      <div class="next-button">
        <button type="submit" id="nextButton" class="btn btn-secondary">Update</button>
      </div>

    </form>
  </div>

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet" />
  <script>
    AOS.init();
  </script>

</body>

</html>
<?php /**PATH D:\Webcravitae\WebPersonal1\resources\views/skills/edit.blade.php ENDPATH**/ ?>