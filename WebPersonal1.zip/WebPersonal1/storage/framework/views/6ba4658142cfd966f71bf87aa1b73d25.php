
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<!DOCTYPE html>
<html lang="en">


<body>


  <!-- Form - Personal Information -->
  <div class="form-container">
    <!-- Form -->

    <form action="#">


      <div class="input2">

        <div class="label">
          <div class="label2">Description (Optional)</div>
        </div>
        <div class="frame">
          <div class="frame2">
            <!-- Mengganti input tipe text dengan text yang lebih besar -->
            <input type="text" name="desc" placeholder="Enter text">
          </div>
        </div>
      </div>

      <div class="judul">
        <h1>Personal Information</h1>
      </div>



      <div class="input">
        <div class="label">
          <label for="full-name" class="label2">Full Name</label>
        </div>
        <div class="frame">
          <div class="frame2">
            <input type="text" id="full-name" name="full-name" placeholder="Enter text" required>
          </div>
        </div>
      </div>

      <div class="input3">
        <div class="label">
          <div class="label2">Address</div>
        </div>
        <div class="frame">
          <div class="frame2">
            <input type="text" id="alamat" name="alamat" placeholder="Enter Text" required>
          </div>
        </div>
      </div>

      <div class="input4">
        <div class="label">
          <div class="label2">City</div>
        </div>
        <div class="frame">
          <div class="frame2">
            <input type="text" id="kota" name="kota" placeholder="Enter text" required>
          </div>
        </div>
      </div>
      <div class="input5">
        <div class="label">
          <div class="label2">Telephone number</div>
        </div>
        <div class="frame">
          <div class="frame2">
            <input type="tel" id="phone" name="phone" placeholder="Enter number" required>
          </div>
        </div>
      </div>
      <div class="input6">
        <div class="label">
          <div class="label2">Email</div>
        </div>
        <div class="frame">
          <div class="frame2">
            <input type="email" id="mail" name="mail" placeholder="Enter email" required>
          </div>
        </div>
      </div>
      <div class="input7">
        <div class="label">
          <div class="label2">Link Profile</div>
        </div>
        <div class="frame">
          <div class="frame2">
            <input type="url" id="ling" name="ling" placeholder="Enter link">
          </div>
        </div>
      </div>
    </form>
    
  </div>

  <div class="next-button">
        <button type="submit" id="nextButton" class="btn btn-secondary">Next→</button>
      </div>


</body>





















    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>
                            Personal Information
                            <a href="<?php echo e(url('personal')); ?>" class="btn btn-primary float-end">BACK</a>
                        </h4>
                    </div>
                    <div class="card-body">

                        <form action="<?php echo e(url('/personalstore')); ?> " method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <h4>Personal Information</h4>

                            <div class="mb3">
                                <label>Masukkan Foto</label>
                                <input type="file" name="foto" class="form control">
                            </div>

                            <div class="mb3">
                                <label>Deskripsi</label>
                                <input type="text" name="deskripsi" class="form control">
                            </div>

                            <div class="mb3">
                                <label>Full Name</label>
                                <input type="text" name="full_name" class="form control">
                            </div>

                            <div class="mb3">
                                <label>Email</label>
                                <input type="email" name="email" class="form control">
                            </div>

                            <div class="mb3">
                                <label>Phone Number</label>
                                <input type="tel" name="telephone_number" class="form control">
                            </div>

                            <div class="mb3">
                                <label>City</label>
                                <input type="text" name="city" class="form control">
                            </div>

                            <div class="mb3">
                                <label>Address</label>
                                <input type="text" name="address" class="form control">
                            </div>

                            <div class="mb3">
                                <label>Link Profile</label>
                                <input type="text" name="link_profile" class="form control">
                            </div>

                            <h4>Education</h4>
                            <div class="mb3">
                                <label>Education Institution</label>
                                <input type="text" name="Edu_institution" class="form control">
                            </div>

                            <div class="mb3">
                                <label>Education Location</label>
                                <input type="text" name="Loc_edu" class="form control">
                            </div>

                            <div class="mb3">
                                <label>Start Date</label>
                                <input type="date" name="Start_date_edu" class="form control">
                            </div>

                            <div class="mb3">
                                <label>End Date</label>
                                <input type="date" name="End_date_edu" class="form control">
                            </div>

                            <div class="mb3">
                                <label>Achievement</label>
                                <input type="text" name="Achievment" class="form control">
                            </div>

                            <div class="mb3">
                                <label>Education Level</label>
                                <input type="text" name="Education_level" class="form control">
                            </div>

                            <h4>Experience</h4>
                            <div class="mb3">
                                <label>Company Name</label>
                                <input type="text" name="Company_name" class="form control">
                            </div>

                            <div class="mb3">
                                <label>Company Location</label>
                                <input type="text" name="Loc_org" class="form control">
                            </div>

                            <div class="mb3">
                                <label>Start Date Company</label>
                                <input type="date" name="Start_date_org" class="form control">
                            </div>

                            <div class="mb3">
                                <label>End Date Company</label>
                                <input type="date" name="End_date_org" class="form control">
                            </div>

                            <div class="mb3">
                                <label>Job Title</label>
                                <input type="text" name="Job_title" class="form control">
                            </div>

                            <div class="mb3">
                                <label>Job Description</label>
                                <input type="text" name="Job_desc" class="form control">
                            </div>

                            <div class="mb-3">
                                <button type="submit" class ="btn btn-primary"> Submit </button>
                            </div>

                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>










</html>



    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" rel="stylesheet" />
    <script>
        AOS.init();
    </script>

<?php /**PATH D:\Webcravitae\WebPersonal1\resources\views/form-personal.blade.php ENDPATH**/ ?>