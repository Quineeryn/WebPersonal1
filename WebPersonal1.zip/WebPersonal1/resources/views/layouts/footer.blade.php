<!-- Bagian Bawah Halaman -->
<footer>
    <p>© 2023 Cravitae. Project for Proyek 3.</p>
</footer>
