<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="stylesheet" href="../css/cravitae.css">


  <title>Home - Cravitae</title>
</head>


    <!-- Header -->
    <header>
    <div class="logo">
      <span class="cravitae">Cravitae</span>
    </div>

    <nav class="menu">
      <span></span>
      <a href="#" class="navbar">Home</a>
      <a href="#" class="navbar">About Me</a>
      <a href="#" class="navbar">Resume</a>
      <a href="#" class="navbar">Portofoliio</a>
      <a href="#" class="navbar">Contact</a>

    </nav>

    <div class="acc-signout">
      <div class="frame-acc-signout">

        <div class="circle-acc">
          <!-- <div class="one-font">
            C
          </div> -->

          <a href="#" class="one-font">C</a>
          
        </div>

        <div class="name-font">
        {{ Auth::user()->name }} 
        </div>
      </div>

      <a href="{{ url('/logout') }}" class="sign-out"> Sign Out →</a>
      
    </div>


  </header>



  <!-- End Header -->