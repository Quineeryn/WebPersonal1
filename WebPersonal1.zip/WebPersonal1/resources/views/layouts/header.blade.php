<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="stylesheet" href="../css/cravitae.css">


  <title>Home - Cravitae</title>
</head>


    <!-- Header -->
    <header>
    <div class="logo">
      <span class="cravitae">Cravitae</span>
    </div>

    <nav class="menu">
      <span></span>
      <a href="{{ url('/') }}" class="navbar">Home</a>
      <a href="{{ url('about') }}" class="navbar">About</a>
    </nav>

    @if (Auth::guest())
    <!-- Login
    Register -->
    <li><a href="{{ url('/login') }}">Login</a></li>
    <li><a href="{{ url('/register') }}">Register</a></li>
    
    @else
    <div class="acc-signout">
      <div class="frame-acc-signout">

        <div class="circle-acc">
          <!-- <div class="one-font">
            C
          </div> -->

          <a href="#" class="one-font">C</a>
          
        </div>

        <div class="name-font">
        {{ Auth::user()->name }} 
        </div>
      </div>

      <a href="{{ url('/logout') }}" class="sign-out"> Sign Out →</a>
      
    </div>
    @endif

  </header>



  <!-- End Header -->