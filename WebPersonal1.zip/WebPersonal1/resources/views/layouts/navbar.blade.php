

  <!-- Navtab Form -->
  <div class="satuin">

    <div class="navbarform-grup">

      <div class="line"></div>

      <!-- 1 Personal Information -->

      <div class="navbaer navbarform-1 color-black">
        <a href="../views/form-personal.html" class="font-angka">1</a>
      </div>
      <a href="../views/form-personal.html" class="labelform posisiform1">Personal Information</a>
    </div>

    <!-- 2 Education -->
    <div class="navbaer navbarform-2 color-grey">
      <a href="../views/form-education.html" class="font-angka">2</a>
    </div>
    <a href="../views/form-education.html" class="labelform posisiform2">Education</a>

    <!-- 3 Experience -->
    <div class="navbaer navbarform-3 color-grey">
      <a href="../views/form-experience.html" class="font-angka">3</a>
    </div>
    <a href="../views/form-experience.html" class="labelform posisiform3">Experience</a>

    <!-- 4 Skill -->
    <div class="navbaer navbarform-4 color-grey">
      <a href="../views/form-skill.html" class="font-angka">4</a>
    </div>
    <a href="../views/skills.html" class="labelform posisiform4">Skill</a>


    <!-- 5 Tambahan -->
    <div class="navbaer navbarform-5 color-grey">
      <a href="#" class="font-angka">5</a>
    </div>
    <a href="#" class="labelform posisiform5">More</a>

  </div>