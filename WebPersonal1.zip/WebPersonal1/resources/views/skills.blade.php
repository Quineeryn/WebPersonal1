

@extends('layouts.app')

@section('content')
    <div class="container">
        <h2>Skills</h2>

        <div class="row skills-content">
            @foreach($skills as $skill)
                <div class="col-lg-6">
                    <div class="progress">
                        <span class="skill">{{ $skill->name }} <i class="val">{{ $skill->range }}%</i></span>
                        <div class="progress-bar-wrap">
                            <div class="progress-bar" role="progressbar" aria-valuenow="{{ $skill->range }}"
                                aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
@endsection

