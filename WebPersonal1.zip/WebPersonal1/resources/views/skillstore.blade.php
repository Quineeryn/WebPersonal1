@extends('layouts.header')

@extends('layouts.navbar')

<!DOCTYPE html>
<html lang="en">

<body>

    <div class="container mt-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>
                            Skill Information
                            <a href="{{ route('personal.edit', $personalId) }}" class="btn btn-primary float-end">BACK</a>
                        </h4>
                    </div>
                    <div class="card-body">

                        <form action="{{ route('personal.skillstore', $personalId) }}" method="POST">
                            @csrf
                            <h4>Add Skill</h4>

                            <div class="mb3">
                                <label>Skill Name</label>
                                <input type="text" name="nama_skill" class="form control" required>
                            </div>

                            <div class="mb3">
                                <label>Skill Range (1-100)</label>
                                <input type="number" name="rentan_skill" class="form control" min="1" max="100" required>
                            </div>

                            <div class="mb-3">
                                <button type="submit" class="btn btn-primary">Add Skill</button>
                            </div>

                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

</html>
